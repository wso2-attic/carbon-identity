package com.example.azone;

public class OauthCostants {
	final static String REDIRECT_URL = "http://wso2.com";
	final static String CLIENT_ID = "nZQREUlViaeVJDb78HF37GWwfYMa";
	final static String CLIENT_SECRET = "BNcJ4hIzG58vCS8RHywCpWe3Wkoa";
	final static String TRUSTSTORE_PASSWORD = "wso2carbon";
}
