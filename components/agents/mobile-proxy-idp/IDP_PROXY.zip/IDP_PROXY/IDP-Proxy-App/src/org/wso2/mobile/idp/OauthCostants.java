package org.wso2.mobile.idp;

public class OauthCostants {
	final static String CLIENT_ID = "nsl2n6NOUBQZ3wwIfdxOrSWSHU0a";
	final static String CLIENT_SECRET = "SO6zhE_NffVUVMWlJ5SzfPmALJQa";
	final static String CALL_BACK_URL = "http://wso2.com";
	final static String INFO = "INFO";
}
