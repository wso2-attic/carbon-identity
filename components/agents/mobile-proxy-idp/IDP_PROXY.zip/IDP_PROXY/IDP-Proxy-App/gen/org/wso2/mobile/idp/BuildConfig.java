/** Automatically generated file. DO NOT MODIFY */
package org.wso2.mobile.idp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}